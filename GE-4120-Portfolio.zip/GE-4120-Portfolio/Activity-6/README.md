<div align="center">

# 🎀 ACTIVITY 6

### GE 4120 · Civil Engineering

* A record of my learning and progress *

</div>

---

## 📌 Activity Title

**[Replace with the actual title of Activity 6]**

## 📝 Activity Description

[Briefly explain what this activity was about and what you were asked to do.]

## 💡 What Have I Learned?

Write at least **3–5 sentences** or use bullet points. Include:

- [Describe an important concept or skill you learned.]
- [Explain another thing you learned or practiced.]
- [Describe a challenge you encountered and how you solved it.]
- [Explain how you could apply or improve this skill in the future.]

## 🧩 Challenges & Solutions

[Describe one challenge you faced while completing the activity and explain the steps you took to overcome it.]

## 🚀 Future Application

[Explain how you can use what you learned in future activities, other courses, or Civil Engineering tasks.]

## 📁 Activity Files

Add your actual activity files to this folder. List or link them here if helpful.

---

<div align="center">

[⬅ Back to Main Portfolio](../README.md)

**Made with 💗 by Chloe Aiah A. Manaopanao**

</div>
