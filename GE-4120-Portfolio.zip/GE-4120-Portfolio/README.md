<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=ffb6d5&height=190&section=header&text=Chloe's%20Portfolio&fontSize=38&fontColor=ffffff&animation=fadeIn" width="100%" />

# 🎀 CHLOE AIAH A. MANAOPANAO

### GE 4120 | Civil Engineering Portfolio

**Ateneo de Davao University · 3rd Year Civil Engineering**

[![Course](https://img.shields.io/badge/COURSE-GE%204120-ec8ab5?style=for-the-badge)]()
[![Portfolio](https://img.shields.io/badge/PORTFOLIO-2026-f4a6c8?style=for-the-badge)]()

*Learning, creating, and building one activity at a time.* 🌷

</div>

---

## 🌸 About Me

Hello! I'm **Chloe Aiah A. Manaopanao**, a third-year Civil Engineering student at **Ateneo de Davao University**.

This repository is my GE 4120 portfolio. It contains my course activities, files, and reflections on the skills and concepts I develop throughout the course. I am interested in exploring how technology and computational tools can support engineering work and problem-solving.

> 📷 **Add your profile photo:** Upload an image to this repository (for example, `images/profile.jpg`) and replace this note with:
> `![Chloe's profile photo](images/profile.jpg)`

## 💻 Skills & Tools

- AutoCAD
- Microsoft Excel
- SMath Studio
- Surveying instruments
- Analytical thinking and engineering problem-solving

## 📚 Course Activities

| Folder | Activity |
|:--|:--|
| [🎀 Activity 1](Activity-1/) | Activity 1 files and reflection |
| [🎀 Activity 2](Activity-2/) | Activity 2 files and reflection |
| [🎀 Activity 3](Activity-3/) | Activity 3 files and reflection |
| [🎀 Activity 4](Activity-4/) | Activity 4 files and reflection |
| [🎀 Activity 5](Activity-5/) | Activity 5 files and reflection |
| [🎀 Activity 6](Activity-6/) | Activity 6 files and reflection |
| [🎀 Activity 7](Activity-7/) | Activity 7 files and reflection |

## 🎯 Learning Goals

- Strengthen my understanding of the concepts covered in GE 4120.
- Improve my ability to use computational and technical tools.
- Practice solving problems through logical and analytical thinking.
- Connect course concepts to possible Civil Engineering applications.

## 📌 Repository Guide

Each activity has its own folder containing:
1. The activity's submitted files.
2. A `README.md` describing the activity.
3. A short reflection on what I learned, the challenge I faced, and how I can apply the learning in the future.

---

<div align="center">

### 💗 Thank you for visiting my portfolio!

<img src="https://capsule-render.vercel.app/api?type=waving&color=ffb6d5&height=110&section=footer" width="100%" />

</div>
